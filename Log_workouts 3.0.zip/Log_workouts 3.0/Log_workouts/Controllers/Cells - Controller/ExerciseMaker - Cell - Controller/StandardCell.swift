import UIKit
import SwipeCellKit

class StandardCell: SwipeTableViewCell {
    @IBOutlet weak var orderLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    

    
}
