import UIKit

class SuperSetHeadingCell: UITableViewCell {
    @IBOutlet weak var setName: UILabel!
    
    @IBOutlet weak var setAmounts: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    
}
